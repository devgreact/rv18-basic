# React 18 버전 기본 구성

- emotion
- sass
- ant
- eslint
- prettier
- react-router
- react-router-dom
- axios
